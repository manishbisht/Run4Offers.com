<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" 
      type="image/png"
      href="images/logo.jpg"
      sizes="32x32">
<title>Run4Offer</title>
</head>
<link rel="stylesheet" type="text/css" href="main.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3&appId=645498488883027";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<center>
<nav class="fixedbar">
<ul class="fancyNav">
<li id="home"><a href="#home" class="homeIcon">Logo</a></li>
<li><a href="index.html">Home</a></li>
<li><a href="flipkart.php">Offers by Flipkart</a></li>
<li onclick="alert('Sorry !!\nComplete Portal Comming Soon\nVisit After Some Time :)');"><a href="index.html">About Us</a></li>
<li onclick="alert('Sorry !!\nComplete Portal Comming Soon\nVisit After Some Time :)');"><a href="index.html">Login/SignUp</a></li>
</ul>
</nav>
<table border="0" bgcolor="#FFFFFF">
<tr height="40">
<td width="162">&nbsp;</td>
<td width="442">&nbsp;</td>
<td width="162">&nbsp;</td>
</tr>
  <tr>
    <td colspan="3" scope="row">
      <img src="images/header.jpg"/>
      <br />
      <center>
        <script type="text/javascript" language="javascript"> var aax_size='728x90'; var aax_pubname = 'shoppinghub-21'; var aax_src='302'; </script><script type="text/javascript" language="javascript" src="http://c.amazon-adsystem.com/aax2/assoc.js"></script>
        <br />
        <iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-141743223778542585' frameborder=0 height=90 width=728></iframe>
        </center>
      </td>
    <td width="297"><div class="fb-page" data-href="https://www.facebook.com/newshoppinghub" data-width="300" data-height="610" data-hide-cover="false" data-show-facepile="true" data-show-posts="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/newshoppinghub"><a href="https://www.facebook.com/newshoppinghub">Shopping Hub</a></blockquote></div></div></td>
  </tr>
  <tr>
    <td height="67" colspan="3" scope="row">
	    <center>
	      <?php
include "flipkartapi.php";

$flipkart = new Flipkart("bestshopp", "21719d092a4c47bba14ee26dc9726988", "json");

$dotd_url = 'https://affiliate-api.flipkart.net/affiliate/offers/v1/dotd/json';
$topoffers_url = 'https://affiliate-api.flipkart.net/affiliate/offers/v1/top/json';

$url = isset($_GET['url'])?$_GET['url']:false;
if($url){
	$url = base64_decode($url);
	$hidden = isset($_GET['hidden'])?false:true;
	$details = $flipkart->call_url($url);
	if(!$details){
		echo 'Error: Could not retrieve products list.';
		exit();
	}
	$details = json_decode($details, TRUE);
	$nextUrl = $details['nextUrl'];
	$validTill = $details['validTill'];
	$products = $details['productInfoList'];

	echo '<h2><a href="?">FLIPKART HOME</a> | <a href="?url='.base64_encode($nextUrl).'">NEXT >></a></h2>';
	if($hidden)
		echo 'Products that are out of stock are hidden by default.<br><a href="?hidden=1&url='.base64_encode($url).'">SHOW OUT-OF-STOCK ITEMS</a><br><br>';
		
	echo "<table border=2 cellpadding=10 cellspacing=1 style='text-align:center'>";
	$count = 0;
	$end = 1;
	if(count($products) > 0){
		foreach ($products as $product) {
			$inStock = $product['productBaseInfo']['productAttributes']['inStock'];
			if(!$inStock && $hidden)
				continue;
			$count++;
			$productId = $product['productBaseInfo']['productIdentifier']['productId'];
			$title = $product['productBaseInfo']['productAttributes']['title'];
			$productDescription = $product['productBaseInfo']['productAttributes']['productDescription'];
			$productImage = array_key_exists('100x100', $product['productBaseInfo']['productAttributes']['imageUrls'])?$product['productBaseInfo']['productAttributes']['imageUrls']['100x100']:'';
			$sellingPrice = $product['productBaseInfo']['productAttributes']['sellingPrice']['amount'];
			$productUrl = $product['productBaseInfo']['productAttributes']['productUrl'];
			$productBrand = $product['productBaseInfo']['productAttributes']['productBrand'];
			$color = $product['productBaseInfo']['productAttributes']['color'];
			$productUrl = $product['productBaseInfo']['productAttributes']['productUrl'];
			$end = 0;
			if($count%3==1)
				echo '<tr><td>';
			else if($count%3==2)
				echo '</td><td>';
			else{
				echo '</td><td>';
				$end =1;
			}

			echo '<a target="_blank" href="'.$productUrl.'"><img src="'.$productImage.'"/><br>'.$title."</a><br>Rs. ".$sellingPrice;

			if($end)
				echo '</td></tr>';

		}
	}
	if($count==0){
		echo '<tr><td>The retrieved products are not in stock. Try the Next button or another category.</td><tr>';
	}
	if($end!=1)
		echo '</td></tr>';

	echo '</table>';
	echo '<h2><a href="?url='.base64_encode($nextUrl).'">NEXT >></a></h2>';
	exit();
}
$offer = isset($_GET['offer'])?$_GET['offer']:false;
if($offer){

	if($offer == 'dotd'){
		$details = $flipkart->call_url($dotd_url);

		if(!$details){
			echo 'Error: Could not retrieve DOTD.';
			exit();
		}
		$details = json_decode($details, TRUE);
		$list = $details['dotdList'];
		echo '<h2><a href="?">FLIPKART HOME</a> | DOTD Offers | <a href="?offer=topoffers">TOP Offers</a></h2>';
		echo "<table border=2 cellpadding=10 cellspacing=1 style='text-align:center'>";
		$count = 0;
		$end = 1;
		if(count($list) > 0){
			foreach ($list as $item) {
				$count++;
				$title = $item['title'];
				$description = $item['description'];
				$url = $item['url'];
				$imageUrl = $item['imageUrls'][0]['url'];
				$availability = $item['availability'];
				$end = 0;
				if($count%3==1)
					echo '<tr><td>';
				else if($count%3==2)
					echo '</td><td>';
				else{
					echo '</td><td>';
					$end =1;
				}
				echo '<a target="_blank" href="'.$url.'"><img src="'.$imageUrl.'" style="max-width:100px; max-height:100px;"/><br>'.$title."</a><br>".$description;

				if($end)
					echo '</td></tr>';

			}
		}
		if($count==0){
			echo '<tr><td>No DOTDs returned.</td><tr>';
		}
		if($end!=1)
			echo '</td></tr>';

		echo '</table>';
		exit();
	}else if($offer == 'topoffers'){
		$details = $flipkart->call_url($topoffers_url);
		if(!$details){
			echo 'Error: Could not retrieve Top Offers.';
			exit();
		}
		$details = json_decode($details, TRUE);
		$list = $details['topOffersList'];
		echo '<h2><a href="?">HOME</a> | <a href="?offer=dotd">DOTD Offers</a> | Top Offers</h2>';
		echo "<table border=2 cellpadding=10 cellspacing=1 style='text-align:center'>";
		$count = 0;
		$end = 1;
		if(count($list) > 0){
			foreach ($list as $item) {
				$count++;
				$title = $item['title'];
				$description = $item['description'];
				$url = $item['url'];
				$imageUrl = $item['imageUrls'][0]['url'];
				$availability = $item['availability'];
				$end = 0;
				if($count%3==1)
					echo '<tr><td>';
				else if($count%3==2)
					echo '</td><td>';
				else{
					echo '</td><td>';
					$end =1;
				}
				echo '<a target="_blank" href="'.$url.'"><img src="'.$imageUrl.'" style="max-width:100px; max-height:100px;"/><br>'.$title."</a><br>".$description;
				if($end)
					echo '</td></tr>';

			}
		}
		if($count==0){
			echo '<tr><td>No Top Offers returned.</td><tr>';
		}
		if($end!=1)
			echo '</td></tr>';

		echo '</table>';
		exit();

	}else{
		echo 'Error: Invalid offer type.';
		exit();
	}

}
$home = $flipkart->api_home();
if($home==false){
	echo 'Error: Could not retrieve API homepage';
	exit();
}
$home = json_decode($home, TRUE);

$list = $home['apiGroups']['affiliate']['apiListings'];

echo '<h1>Run4Offers Flipkart Home</h1><h2><a href="?offer=dotd">DOTD Offers</a> | <a href="?offer=topoffers">Top Offers</a></h2>Click on a category link to show available products from that category.<br><br>';

echo '<table border=2 style="text-align:center;">';
$count = 0;
$end = 1;
foreach ($list as $key => $data) {
	$count++;
	$end = 0;

	if($count%3==1)
		echo '<tr><td>';
	else if($count%3==2)
		echo '</td><td>';
	else{
		echo '</td><td>';
		$end =1;
	}

	echo "<strong>".$key."</strong>";
	echo "<br>";
	echo '<a href="?url='.base64_encode($data['availableVariants']['v0.1.0']['get']).'">View Products &raquo;</a>';
}

if($end!=1)
	echo '</td></tr>';
echo '</table>';
?>
        </center>
    </td>
    <td rowspan="2"><iframe src='http://www.flipkart.com/affiliate/displayWidget?affrid=WRID-141732585043864259' frameborder=0 height=250 width=300></iframe>  <br />    <script charset="utf-8" type="text/javascript">
amzn_assoc_ad_type = "responsive_search_widget";
amzn_assoc_tracking_id = "shoppinghub-21";
amzn_assoc_link_id = "XEL3HT3SHJ52JAI2";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "IN";
amzn_assoc_placement = "";
amzn_assoc_search_type = "search_widget";
amzn_assoc_width = 300;
amzn_assoc_height = 250;
amzn_assoc_default_search_category = "";
amzn_assoc_default_search_key = "";
amzn_assoc_theme = "light";
amzn_assoc_bg_color = "FFFFFF";
</script>
      <script src="//z-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1&MarketPlace=IN"></script>
      <br />
      <a href="http://www.snapdeal.com/products/computers-laptops?utm_source=aff_prog&utm_campaign=afts&offer_id=17&aff_id=27286" target="_blank">
        <img src="http://125.63.90.53/affprog/banner/Snapdeal-21-april-banner-7.jpg" alt="Shop Now" style="width:300px;height:250px;border:0">
        </a>
      <br />
      <div data-WRID="WRID-143312838237777061" data-widgetType="featuredDeals"  data-class="affiliateAdsByFlipkart" height="250" width="300"></div><script async src="//affiliate-static.flixcart.com/affiliate/widgets/FKAffiliateWidgets.js"></script>
      <br />
      <div data-WRID="WRID-143312650688251292" data-widgetType="featuredDeals"  data-class="affiliateAdsByFlipkart" height="250" width="300"></div><script async src="//affiliate-static.flixcart.com/affiliate/widgets/FKAffiliateWidgets.js"></script>      </td>
  </tr>
  <tr>
    <td height="68" colspan="3" scope="row"></td>
  </tr>
  <tr>
    <td scope="row">&nbsp;</td>
    <td colspan="2" align="center" valign="middle" scope="row">
      <br />
      <strong>
        Disclaimer</strong> :We can not guarantee that the information on this page is 100% correct.<br /><br />
      <strong>Designed, Developed and Maintained by</strong> : Manish Bisht, Sonal Jain and Nishank Garg<br /><br />
      <strong>&copy;All Rights Reserved 2015</strong>
      <br />
      </td>
    <td align="center">
      Page Last Updated on <strong>08 June 2015 </strong></td>
  </tr>
</table>
</center>

</body>
</html>
