<?php
include "flipkartapi.php";

$flipkart = new Flipkart("bestshopp", "21719d092a4c47bba14ee26dc9726988", "json");

$dotd_url = 'https://affiliate-api.flipkart.net/affiliate/search/json?resultCount=10&query=Apple+mobiles';


		$details = $flipkart->call_url($dotd_url);

		if(!$details){
			echo 'Error: Could not retrieve DOTD.';
			exit();
		}
		$details = json_decode($details, TRUE);
		$list = $details['productInfoList'];
		echo $_POST['subject'];
		echo "<center><table border=1 cellpadding=10 cellspacing=1 style='text-align:center'>";
		echo '<tr><td colspan=2><form name="search" method="post"><input type="text" name="subject" id="subject" value="Apple Mobiles"><input type="button" value="Search"></form></td></tr>' ;

		$count = 0;
		$end = 1;
		if(count($list) > 0){
			foreach ($list as $item) {
				$count++;
				$title = $item['productBaseInfo'];
				$id=$title['productIdentifier'];
				$number=$id['productId'];
				$description = $title['productAttributes'];
				$name=$description['title'];
				$url = $description['productUrl'];
				$imageUrl = $description['imageUrls']['275x275'];
				$availability = $description['sellingPrice'];
				$price=$availability['amount'];
				$end = 0;
				echo '<tr><td align="left"><a href="'.$url.'"><img src="'.$imageUrl.'"/></a></td><td width="600px" align="left"><font color=red size=6>'.$name."</font><br>".$name."<br>".$price.'.00</td></tr>';

			}
		}
		if($count==0){
			echo '<tr><td>No DOTDs returned.</td><tr>';
		}
		exit();
if($end!=1)
	echo '</td></tr>';
echo '</table></center>';
?>